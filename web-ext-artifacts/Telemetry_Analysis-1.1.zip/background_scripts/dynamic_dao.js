// // DAO connection to database here
console.log("DAO loaded");
//
// function logCookie(c) {
//   console.log(c);
// }
//
// function logError(e) {
//   console.error(e);
// }
//
// var setCookie = browser.cookies.set({ url: "https://developer.mozilla.org/" });
// setCookie.then(logCookie, logError);

/**
DynamicDao - Micah Hobby - 17027531

Handles database installation / removal and performing CRUD operations.
Also performs persisting the database to long term storage in IndexedDB.
The database used during execution is SQL.js a javascript library that allows
for creating virtual databases in memory using WebAssembly.
At the beggining and end of each session the database is retrieved or stored
to the persistant IndexedDB storage.
**/

// Hook that triggers database script.
browser.runtime.onInstalled.addListener(handleInstall);

/*
 * handleInstall() - hooks runtime.onInstalled()
 *
 * Fired when the extension is first installed or updated,
 * checks for the database or initialises it.
 *
 * @param {object}      details         Contains information related
 *                                      to the install/upgrade process.
 *
 * @return {boolean}    success         Returns outcome of the operation
 */
async function handleInstall(details) {
  const config = {
    locateFile: filename => `../node_modules/sql.js/dist/${filename}`
  }
  const initSqlJs = window.initSqlJs;
  const SQL = await initSqlJs(config);
  console.log("sql.js loaded");

  const loadDb = await window.localforage.getItem("database")
  console.log(loadDb);

  if (loadDb) {
    console.log("db loaded well");
    var db = new SQL.Database(toBinArray(loadDb));

  } else{

    console.log("creating db");
    //Create the database
    var db = new SQL.Database();
    console.log(db);
    // Run a query without reading the results
    db.run("CREATE TABLE test (col1, col2);");
    // Insert two rows: (1,111) and (2,222)
    db.run("INSERT INTO test VALUES (?,?), (?,?)", [1,111,2,222]);

    localforage.config({
      //driver      : localforage.WEBSQL, // Force WebSQL; same as using setDriver()
      name        : 'appStorage',
      version     : 1.0,
      size        : 4980736, // Size of database, in bytes. WebSQL-only for now.
      storeName   : 'database', // Should be alphanumeric, with underscores.
      description : 'sqlite local database for TelemetryAnalysis'
    });

    // save
    await window.localforage.setItem("database", toBinString(db.export()));

  }

}

/*
 * toBinString()
 *
 * Exports database to string, allows for saving to IndexedDB
 *
 * @param {Uint8Array}      arr         Array containing the database export
 *                                      to the install/upgrade process.
 *
 * @return {String}         strings     String version of the database
 */
function toBinString(arr) {
  var uarr = new Uint8Array(arr);
  var strings = [], chunksize = 0xffff;
  // There is a maximum stack size. We cannot call String.fromCharCode with as many arguments as we want
  for (var i = 0; i * chunksize < uarr.length; i++) {
    strings.push(String.fromCharCode.apply(null, uarr.subarray(i * chunksize, (i + 1) * chunksize)));
  }
  return strings.join('');
}

/*
 * toBinArray()
 *
 * Restores database from string to javascript database
 *
 * @param {String}         str         String version of the database
 *
 * @return {Uint8Array}    arr         Converted array version of database
 */
function toBinArray (str) {
  var l = str.length,
      arr = new Uint8Array(l);
  for (var i=0; i<l; i++) arr[i] = str.charCodeAt(i);
  return arr;
}

/*
 * retrieveDatabase()
 *
 * Retrieves sqlite string persisted in indexedDB
 *
 * @param {string}      name         Name for the new database
 *
 * @return {boolean}    success         Returns outcome of the operation
 */
 async function retrieveDatabase(name){

  };

/*
 * createDatabase()
 *
 * Creates database in sql.js and persists it to indexedDB
 *
 * @param {string}      name         Name for the new database
 *
 * @return {boolean}    success         Returns outcome of the operation
 */
 async function createDatabase(name) {

 }

// config = {
//   locateFile: filename => `../node_modules/sql.js/dist/${filename}`
// }
//
// var initSqlJs = window.initSqlJs;
//
// // The `initSqlJs` function is globally provided by all of the main dist files if loaded in the browser.
// // We must specify this locateFile function if we are loading a wasm file from anywhere other than the current html page's folder.
// initSqlJs(config).then(function(SQL){
//
//   async function run(db) {
//
//     //Create the database
//     var db = new SQL.Database();
//     // Run a query without reading the results
//     db.run("CREATE TABLE test (col1, col2);");
//     // Insert two rows: (1,111) and (2,222)
//     db.run("INSERT INTO test VALUES (?,?), (?,?)", [1,111,2,222]);
//
//     // Prepare a statement
//     var stmt = db.prepare("SELECT * FROM test WHERE col1 BETWEEN $start AND $end");
//     stmt.getAsObject({$start:1, $end:1}); // {col1:1, col2:111}
//
//     // Bind new values
//     stmt.bind({$start:1, $end:2});
//     while(stmt.step()) { //
//       var row = stmt.getAsObject();
//       console.log('Here is a row: ' + JSON.stringify(row));
//     }
//
//     localforage.config({
//       //driver      : localforage.WEBSQL, // Force WebSQL; same as using setDriver()
//       name        : 'appStorage',
//       version     : 1.0,
//       size        : 4980736, // Size of database, in bytes. WebSQL-only for now.
//       storeName   : 'database', // Should be alphanumeric, with underscores.
//       description : 'sqlite local database for TelemetryAnalysis'
//     });
//
//     // save
//     await window.localforage.setItem("mydata", toBinString(db.export()));
//
//     // restore the database
//     var db = new SQL.Database(toBinArray(await window.localforage.getItem("mydata")));
//
//   }
//
//   run();
//
// });
