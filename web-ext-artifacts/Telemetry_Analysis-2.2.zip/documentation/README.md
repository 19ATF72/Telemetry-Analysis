# Telemetry-Analysis
Adds a browser action to analyze scripts &amp; telemetry on the page.
