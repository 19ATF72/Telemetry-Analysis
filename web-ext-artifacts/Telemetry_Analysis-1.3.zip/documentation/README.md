# Telemetry-Analysis
Adds a browser action to analyse scripts &amp; telemetry on the page.
